# Outreach Automation Demo (Next.js 12)

This is the demo for:
LinkedIn → Data Extraction → Enrichment → CRM Pipeline.

Deploy on Vercel:
1. Upload folder
2. Click Deploy
3. Done
